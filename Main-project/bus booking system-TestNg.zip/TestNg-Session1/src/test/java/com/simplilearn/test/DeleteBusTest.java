package com.simplilearn.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class DeleteBusTest {
	
  @Test
  public void deleteBus() throws InterruptedException {
	  
		//Setting up the driver and getting the website
		  String driver_path="D:\\\\selenium\\\\chromedriver.exe";
		  System.setProperty("webdriver.chrome.driver", driver_path);
		  WebDriver driver = new ChromeDriver();
		  driver.get("http://localhost:4200/login");
		  
		  WebElement loginLink = driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/ul[2]/li[2]/a/b"));
		  loginLink.click();
		  
		  //Waiting to go to login page
		  Thread.sleep(1000);
		  
		  //sending the user name
		  WebElement email = driver.findElement(By.xpath("/html/body/app-root/app-login/div/div/form/div[1]/input"));
		  email.sendKeys("kumar@gmail.com");
				
		  //sending the password
		  WebElement password = driver.findElement(By.xpath("/html/body/app-root/app-login/div/div/form/div[2]/input"));
		  password.sendKeys("kumar");
		    
		  //click Submit
		  WebElement login = driver.findElement(By.xpath("/html/body/app-root/app-login/div/div/form/button"));
		  login.submit();
		
		  Thread.sleep(3000); 
		  System.out.println("LoggedIn as admin");
		  
		  //enter bus_Id
		  WebElement bus_Id = driver.findElement(By.xpath("/html/body/app-root/app-login/div/div/form/div[1]/input"));
		  bus_Id.sendKeys("101");
		  
		  //click on Submit botton to delete bus
		  WebElement delete = driver.findElement(By.xpath("/html/body/app-root/app-login/div/div/form/button"));
		  delete.submit();
		  
		
		  driver.close();
  }
}
