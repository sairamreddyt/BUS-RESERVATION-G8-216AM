package com.simplilearn.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class RegisterTest {
	
	
	
  @Test
  public void adminLogin() throws InterruptedException{
	  
	  //Setting up the driver and getting the website
	  String driver_path="D:\\\\selenium\\\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", driver_path);
		WebDriver driver = new ChromeDriver();
		driver.get("http://localhost:4200/register");
		
		//Clicking the admin link to go to admin login page
		WebElement adminLink = driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/ul[2]/li[1]/a/b"));
		adminLink.click();
		
		//Waiting to go to Admin page
		Thread.sleep(1000);
		
		//sending admin id
		WebElement userId = driver.findElement(By.xpath("/html/body/app-root/app-admin/div/div/form/div/div/input[1]"));
		userId.sendKeys("101");
		
		//sending the admin name
		WebElement name = driver.findElement(By.xpath("/html/body/app-root/app-register/div/div/form/div[2]/input"));
		name.sendKeys("kumar");
		
		//sending the user name
		WebElement email = driver.findElement(By.xpath("/html/body/app-root/app-register/div/div/form/div[3]/input"));
		email.sendKeys("kumar@gmail.com");
		
		//sending the password
		WebElement password = driver.findElement(By.xpath("/html/body/app-root/app-register/div/div/form/div[4]/input"));
		password.sendKeys("Krishna");
		
		//click Submit
		WebElement register = driver.findElement(By.xpath("/html/body/app-root/app-register/div/div/form/button"));
		register.submit();
		
		Thread.sleep(3000);
		
		driver.close();
		
		System.out.println("Admin and User can register from here");
		  
  }
}
