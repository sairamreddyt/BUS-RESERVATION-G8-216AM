package com.simplilearn.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class HomeTest {
	
  @Test
  public void home() throws InterruptedException {
	//Setting up the driver and getting the website
	  String driver_path="D:\\\\selenium\\\\chromedriver.exe";
	  System.setProperty("webdriver.chrome.driver", driver_path);
	  WebDriver driver = new ChromeDriver();
	  driver.get("http://localhost:4200");
	  
	  //open home page
	  WebElement home = driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/ul[1]/li/a/b"));
	  home.click();
	  
	  //Waiting to open home page
	  Thread.sleep(1000);
	  
	  //open registre page
	  WebElement register = driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/ul[2]/li[1]/a/b"));
	  register.click();
	  
	  //Waiting to open home page
	  Thread.sleep(1000);
	  
	  //open login page
	  WebElement loginLink = driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/ul[2]/li[2]/a/b"));
	  loginLink.click();
	  
	  //Can directly open home page login also
	  WebElement home1 = driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/ul[1]/li/a/b"));
	  home1.click();
	  
	  System.out.println("Redirected to home page ");
	  
	  //open contactUs
	  WebElement contactUs = driver.findElement(By.xpath("/html/body/app-root/app-footer/div/footer/div/div/div[1]/ul/li[1]/a"));
	  contactUs.click();
	  
	  System.out.println("ContactUs is checked");
	  //Waiting to open home page
	  Thread.sleep(1000);
	  
	  //open AboutUs
	  WebElement aboutUs = driver.findElement(By.xpath("/html/body/app-root/app-footer/div/footer/div/div/div[1]/ul/li[2]/a"));
	  aboutUs.click();
	  
	  System.out.println("AboutUs is checked");
	  
	  //Waiting to open home page from 
	  Thread.sleep(1000);
	  
	  //open AboutUs
	  WebElement Terms_conditions = driver.findElement(By.xpath("/html/body/app-root/app-footer/div/footer/div/div/div[2]/ul/li[1]/a"));
	  Terms_conditions.click();
	  
	  System.out.println("Terms&conditions are checked");
	  
	  Thread.sleep(3000);
	  
	  driver.close();
  }
}
