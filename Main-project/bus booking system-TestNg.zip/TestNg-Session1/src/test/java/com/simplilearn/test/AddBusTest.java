package com.simplilearn.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class AddBusTest {
  @Test
  public void addBus() throws InterruptedException {
	//Setting up the driver and getting the website
	  String driver_path="D:\\\\selenium\\\\chromedriver.exe";
	  System.setProperty("webdriver.chrome.driver", driver_path);
	  WebDriver driver = new ChromeDriver();
	  driver.get("http://localhost:4200/addbus");
	  
	  WebElement loginLink = driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/ul[2]/li[2]/a/b"));
	  loginLink.click();
	  
	  //Waiting to go to login page
	  Thread.sleep(1000);
	  
	  //sending the user name
	  WebElement email = driver.findElement(By.xpath("/html/body/app-root/app-login/div/div/form/div[1]/input"));
	  email.sendKeys("kumar@gmail.com");
			
	  //sending the password
	  WebElement password = driver.findElement(By.xpath("/html/body/app-root/app-login/div/div/form/div[2]/input"));
	  password.sendKeys("kumar");
	    
	  //click Submit
	  WebElement login = driver.findElement(By.xpath("/html/body/app-root/app-login/div/div/form/button"));
	  login.submit();
	
	  Thread.sleep(3000);
	  
	  System.out.println("LoggedIn as admin");
	  
	  //bus Id
	  WebElement busId = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[1]/input"));
	  busId.sendKeys("5");
	  
	  //Bus name
	  WebElement busName = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[1]/input"));
	  busName.sendKeys("Singh travels");
	  
	  //select Bus sourceCity
	  WebElement sourceCity = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[2]/input"));
	  sourceCity.sendKeys("Ongole");
	  
	  //select bus destinationCity
	  WebElement destinationCity = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[3]/input"));
	  destinationCity.sendKeys("Bangalore");
	  
	  //availableSeats
	  WebElement  availableSeats = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[4]/input"));
	  availableSeats.sendKeys("25");
	  
	  //bookedSeats
	  WebElement  bookedSeats = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[5]/input"));
	  bookedSeats.sendKeys("10");
	  
	  //select price
	  WebElement  price = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[6]/input"));
	  price.sendKeys("25");
	  
	  //click Submit
	  WebElement add = driver.findElement(By.xpath("/html/body/app-root/app-login/div/div/form/button"));
	  add.submit();
	  
	  System.out.println("Bus Added");
	  driver.close();
  }
}
