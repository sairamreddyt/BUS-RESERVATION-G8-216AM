package com.si.junittesting;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.si.entity.User;
import com.si.repository.UserRepository;

@SpringBootTest
public class UserTest {
	
	@Autowired
	UserRepository userRepository;
	

	@Test
	public void insertUser() {
	User U = new User ();
		U.setUserId(1);
		U.setEmail("james@gmail.com");
		U.setPassword("123456");
		
		userRepository.save(U);
		assertNotNull(userRepository.findById(7).get());
	}
	@Test
	public void userLogin() {
		List<User> U = userRepository.findByEmailAndPassword("james@gmail.com", "123456");
		assertEquals("james@gmail.com", ((User) U).getUserName());
		assertEquals("123456", ((User) U).getPassword());
	}


}
