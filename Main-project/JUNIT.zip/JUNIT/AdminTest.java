package com.si.junittesting;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.si.entity.Admin;
import com.si.repository.AdminRepository;

@SpringBootTest
public class AdminTest {
	
	@Autowired
	AdminRepository adminRepository;
	
	@Test
	public void insertAdmin() {
		Admin A = new Admin();
		A.setEmail("james@gmail.com");
		A.setPassword("12345");
		adminRepository.save(A);
		assertNotNull(adminRepository.findById(3).get());
	}
	@Test
	public void adminAuth() {
		List<Admin> A = adminRepository.findByEmailAndPassword("james@gmail.com", "12345");
		assertEquals("james@gmail.com", ((Admin) A).getEmail());
		assertEquals("12345", ((Admin) A).getPassword());
	}

}
