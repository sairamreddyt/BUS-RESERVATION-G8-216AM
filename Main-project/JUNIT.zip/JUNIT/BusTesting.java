package com.si.junittesting;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


import com.si.entity.Bus;
import com.si.repository.BusRepository;

@SpringBootTest
public class BusTesting {
	
	@Autowired
	BusRepository busRepository;
	
	@Test
	public void addbus() {
		Bus b = new Bus();
		b.setBusId(101);
		b.setBusName("Kaveri Travels");
		b.setPrice(500);
		b.setAvailableSeats("35");
		b.setBookedSeats("5");
		b.setSourceCity("Ongole");
		b.setDestinationCity("Hyderabad");
		
		busRepository.save(b);
		assertNotNull(busRepository.findBySearchParameters("ongole", "hyderabad"));
	}
	@Test
	public void findByBusName() {
		
		Bus b1=new Bus();
		b1.setBusName("Kaveri Travels");
		
		busRepository.save(b1);
		assertNotNull(busRepository.findByBusName("Kaveri Travels"));
		
	}
	
	@Test
	public void deleteBus() {
		Bus b2=new Bus();
		b2.setBusId(101);
		
		busRepository.save(b2);
		assertNotNull(busRepository.findById("101"));
	}
	

	
}
