import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  removeOwner(userId: any) {
    throw new Error('Method not implemented.');
  }
  getAllOwner() {
    throw new Error('Method not implemented.');
  }
  avail: any = null;
 
  userUrl = 'http://localhost:8081/user';

  constructor(private http: HttpClient) { }
  register(data) {
    console.log(data);
    return this.http.post<any>(`${this.userUrl}/adduser`, data);
  }
  
  chechAvail(data) {
    return this.http.get<any>(`${this.userUrl}/searchBus/${data.sourceCity}/${data.destinationCity}`);
  }
  bookTicket(data) {
    return this.http.post<any>(`${this.userUrl}/bookBus`, data);
  }
  availa() {
    return this.avail = true;
  }
 
}
