import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  name = '';
  constructor(private router: Router, private userService: UserServiceService) { }
  

  ngOnInit() {
  }
  user(registerUser: NgForm) {
    this.userService.register(registerUser.value).subscribe(data => {
      if (data.user != null) {
        console.log(data);
        registerUser.reset();
      } else {
        console.log(data);
        registerUser.reset();
      }
    });
  }

}
