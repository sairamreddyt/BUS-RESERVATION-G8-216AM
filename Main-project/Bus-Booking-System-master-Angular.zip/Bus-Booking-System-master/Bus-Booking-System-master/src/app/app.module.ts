import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { AddOwnerComponent } from './add-owner/add-owner.component';
import { RemoveOwnerComponent } from './remove-owner/remove-owner.component';
import { AddBusComponent } from './add-bus/add-bus.component';

import { DeleteBusComponent } from './delete-bus/delete-bus.component';
import { GetAllTicketsComponent } from './get-all-tickets/get-all-tickets.component';

import { ShowAllBusesComponent } from './show-all-buses/show-all-buses.component';
import { BookTicketComponent } from './book-ticket/book-ticket.component';
import { CheckAvaliabilityComponent } from './check-avaliability/check-avaliability.component';

import { HomeComponent } from './home/home.component';
import { FooterComponent } from './footer/footer.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    RegisterComponent,
    LoginComponent,
    AddOwnerComponent,
    RemoveOwnerComponent,
    AddBusComponent,
    DeleteBusComponent,
    GetAllTicketsComponent,

    ShowAllBusesComponent,
    BookTicketComponent,
    CheckAvaliabilityComponent,
   
    HomeComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }
