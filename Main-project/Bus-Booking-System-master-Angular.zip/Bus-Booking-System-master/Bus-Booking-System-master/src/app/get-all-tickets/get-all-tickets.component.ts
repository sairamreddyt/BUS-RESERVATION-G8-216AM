import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-get-all-tickets',
  templateUrl: './get-all-tickets.component.html',
  styleUrls: ['./get-all-tickets.component.css']
})
export class GetAllTicketsComponent implements OnInit {
  tickets: any[] = [];
  constructor(private adminService: AdminServiceService) { this.getTickets(); }

  ngOnInit() {
  }
  getTickets() {
    this.adminService.getAllTickets().subscribe(data => {
      console.log(data);
      this.tickets = data.ticketList;
    });
  }

}
