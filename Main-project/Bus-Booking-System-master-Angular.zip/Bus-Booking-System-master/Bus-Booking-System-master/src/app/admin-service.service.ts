import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {
  [x: string]: any;
  avail: any = null;
  ownerUrl = 'http://localhost:8081/admin';
  backendUrl = 'http://localhost:8081/bus';
  constructor(private http:HttpClient) { }
  register(data) {
    console.log(data);
    return this.http.post<any>(`${this.ownerUrl}/addadmin`, data);
  }
  removeOwner(data) {
    return this.http.delete(`${this.ownerUrl}/deleteadmin/${data}`);
  }
  getAllOwner() {
    return this.http.get<any>(`${this.ownerUrl}/adminlist`);
  }
  addBus(data) {
    return this.http.post(`${this.backendUrl}/addbus`, data);
  }
  deleteBus(data) {
    return this.http.delete(`${this.backendUrl}/deleteBus/${data}`);
  }
  getAllTickets() {
    return this.http.get<any>(`${this.backendUrl}/tickets`);
  }
  showAllBus() {
    return this.http.get<any>(`${this.backendUrl}/buslist`);
  }
}
