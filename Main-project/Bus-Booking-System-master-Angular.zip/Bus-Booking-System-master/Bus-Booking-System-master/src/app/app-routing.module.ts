import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AddOwnerComponent } from './add-owner/add-owner.component';
import { RemoveOwnerComponent } from './remove-owner/remove-owner.component';
import { AddBusComponent } from './add-bus/add-bus.component';
import { DeleteBusComponent } from './delete-bus/delete-bus.component';
import { GetAllTicketsComponent } from './get-all-tickets/get-all-tickets.component';

import { ShowAllBusesComponent } from './show-all-buses/show-all-buses.component';
import { BookTicketComponent } from './book-ticket/book-ticket.component';
import { CheckAvaliabilityComponent } from './check-avaliability/check-avaliability.component';

import { HomeComponent } from './home/home.component';
import { FooterComponent } from './footer/footer.component';

const routes: Routes = [
  {path: '', component: HomeComponent},
  {path: 'login', component: LoginComponent},
  {path: 'register', component: RegisterComponent},
  {path: 'addOwner', component: AddOwnerComponent},
  {path: 'removeOwner', component: RemoveOwnerComponent},
  {path: 'addBus', component: AddBusComponent},
  {path: 'deleteBus', component: DeleteBusComponent},
  {path: 'getAllTickets', component: GetAllTicketsComponent},

  {path: 'showAllBuses', component: ShowAllBusesComponent},
  {path: 'bookTicket', component: BookTicketComponent},
  {path: 'checkAvaliability', component: CheckAvaliabilityComponent},

  {path:'contact',component:FooterComponent},
  {path:'about',component:FooterComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
