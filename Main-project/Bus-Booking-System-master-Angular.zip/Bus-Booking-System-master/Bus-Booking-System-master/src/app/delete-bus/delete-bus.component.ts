import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user-service.service';
import { NgForm } from '@angular/forms';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-delete-bus',
  templateUrl: './delete-bus.component.html',
  styleUrls: ['./delete-bus.component.css']
})
export class DeleteBusComponent implements OnInit {
  buss: any = [];
  constructor(private adminService: AdminServiceService) { }

  ngOnInit() {
  }
  deleteBusMethod(deleteBus: NgForm) {
    this.adminService.deleteBus(deleteBus.value.busId).subscribe(bus => {
      this.buss = bus;
      if (this.buss.message === 'Success') {
        console.log(bus);
        deleteBus.reset();
      } else {
        console.log(bus);
        deleteBus.reset();
      }
    }
    );
  }
}