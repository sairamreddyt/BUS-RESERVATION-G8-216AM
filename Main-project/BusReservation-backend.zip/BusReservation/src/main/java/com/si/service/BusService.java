package com.si.service;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.si.entity.Bus;
import com.si.repository.BusRepository;


@Service
public class BusService 
{
	@Autowired
	BusRepository busRepo;
	
	public Bus addNewBus(Bus bus)
	{
		return busRepo.save(bus);
	}
    public List<Bus> getAllBusDetails() 
    {
    	return (List<Bus>) busRepo.findAll();
    }
    public void deleteBus(long busId)
    {
    	 busRepo.deleteById(busId);   	 
    }
    public List <Bus> findBySearchParameters(String sourceCity, String destinationCity) 
    {
		//Date date1=new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(departureDate);  	
        return (List<Bus>) busRepo.findBySearchParameters(sourceCity,destinationCity);
    }
    public Bus findByBusName(String busName) 
    {		
        return busRepo.findByBusName(busName);
    }
}

