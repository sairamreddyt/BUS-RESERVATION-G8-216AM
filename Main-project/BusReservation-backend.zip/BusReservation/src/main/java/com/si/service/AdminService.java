package com.si.service;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.si.entity.Admin;
import com.si.repository.AdminRepository;

@Service
public class AdminService 
{
	@Autowired
	public AdminRepository adminRepo;
	// New admin user insertion
	public Admin insertAdmin(Admin admin)
	{
		return adminRepo.save(admin);
	}
	// getting list of all existing admins
	public List<Admin> getAllAdmin()
	{
		return adminRepo.findAll();
	}
	// remove admin
	public void deleteAdmin(int  id)
	{
		adminRepo.deleteById(id);
	}
	// admin login
	public Admin verifyAdmin(String email, String password)
	{
		return adminRepo.findByEmailAndPassword(email, password).stream().findFirst().orElse(null);
	}	
}
