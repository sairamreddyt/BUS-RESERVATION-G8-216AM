package com.si.service;

import org.springframework.stereotype.Service;

@Service
public class TicketGeneration {

	public TicketGeneration() {
		// TODO Auto-generated constructor stub
	}

}