package com.si.service;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

import com.si.entity.Bus;
import com.si.entity.Invoice;
import com.si.entity.Ticket;
import com.si.entity.User;
import com.si.repository.BusRepository;
import com.si.repository.TicketRepository;
import com.si.repository.UserRepository;



@Service
public class UserService {

	@Autowired
	UserRepository userRepo;
	
	
	@Autowired
	 private BusRepository busRepository;

	
	@Autowired
	 private TicketRepository ticketRepository;
	public User verifyUser(String email, String password)
	{
		return userRepo.findByEmailAndPassword(email, password).stream().findFirst().orElse(null);
	}	
	public User addUser(User user)
	{
		return userRepo.save(user);
	}
    public List <User> getAllUserDetails() 
    {		
        return (List<User>) userRepo.findAll();
    }
    @PostMapping("/bookBus")
    public Invoice bookTicket(String busName, String seatNumber,String userName) throws ParseException 
    {		
		Invoice invoice = new Invoice();
		Date reservationDate = new Date();  
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");  
		String strDate = dateFormat.format(reservationDate); 
		Date reservationDateFormatted =new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(strDate);
		
		String ticketNumber = "Ticket"+strDate+seatNumber;
		
		Bus bus = busRepository.findByBusName(busName);
		User user = userRepo.findByUserName(userName);
		
		String avaiableSeats = bus.getAvailableSeats().replace(","+seatNumber, "");
		String bookedSeats = bus.getBookedSeats()+","+seatNumber;
		
		bus.setBookedSeats(bookedSeats);
		bus.setAvailableSeats(avaiableSeats);
		
		busRepository.save(bus);
		
		Ticket ticket = new Ticket();
		
		ticket.setBus(bus);
		ticket.setUser(user);
		ticket.setReservationDate(reservationDateFormatted);
		ticket.setSeatNumber(seatNumber);
		ticket.setTicketNumber(ticketNumber);
		
		ticketRepository.save(ticket);
		
		invoice.setBusName(busName);
		//invoice.setDepartureDate(bus.getDepartureDate());
		invoice.setDestinationCity(bus.getDestinationCity());
		//invoice.setDuration(bus.getDuration());
		invoice.setEmail(user.getEmail());
		//invoice.setOperator(bus.getOperator());
		invoice.setPrice(bus.getPrice());
		invoice.setSourceCity(bus.getSourceCity());
		invoice.setUserName(userName);
		
        return invoice;
    }
	

}
