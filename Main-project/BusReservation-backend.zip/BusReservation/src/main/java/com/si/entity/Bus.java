package com.si.entity;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "BUS_DETAILS")
public class Bus {

	@Id
	@Column(name = "BUS_Id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long busId;
	
	@Column(name = "BUS_NAME")
	private String busName;
	
	/*@Column(name = "operator", nullable = false)
	private String operator;	
	
	@Column(name = "duration", nullable = false)
	private Integer duration;*/
	
	@Column(name = "price")
	private Integer price;
	
	@Column(name = "AVAILABLE_SEATS",nullable= true)
	private String availableSeats;
	
	@Column(name = "BOOKED_SEATS",nullable=true)
	private String bookedSeats;
	
	@Column(name = "SOURCE_CITY")
	private String sourceCity;
	
	@Column(name = "DESTINATION_CITY")
	private String destinationCity;
	
	@Column(name = "DEPARTURE_DATE", nullable = false)
    @JsonFormat(pattern="yyyy-MM-dd HH:mm")
    private Date departureDate;
		
	@OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name="BUS_ID")
    private Set<Ticket> tickets;
    
	public Bus() {}

	public long getBusId() {
		return busId;
	}

	public void setBusId(long busId) {
		this.busId = busId;
	}

	public String getBusName() {
		return busName;
	}

	public void setBusName(String busName) {
		this.busName = busName;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public String getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(String availableSeats) {
		this.availableSeats = availableSeats;
	}

	public String getBookedSeats() {
		return bookedSeats;
	}

	public void setBookedSeats(String bookedSeats) {
		this.bookedSeats = bookedSeats;
	}

	public String getSourceCity() {
		return sourceCity;
	}

	public void setSourceCity(String sourceCity) {
		this.sourceCity = sourceCity;
	}

	public String getDestinationCity() {
		return destinationCity;
	}

	public void setDestinationCity(String destinationCity) {
		this.destinationCity = destinationCity;
	}

	public Set<Ticket> getTickets() {
		return tickets;
	}

	public void setTickets(Set<Ticket> tickets) {
		this.tickets = tickets;
	}

	
}