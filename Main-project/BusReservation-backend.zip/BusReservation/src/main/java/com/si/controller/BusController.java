package com.si.controller;
import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.si.entity.Bus;
import com.si.entity.Ticket;
import com.si.repository.TicketRepository;
import com.si.service.BusService;


@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/bus")
public class BusController 
{
	@Autowired
	private BusService busService;
	
	@Autowired
	 private TicketRepository ticketRepository;
	
	/*Add New Bus 
	 	Inputs to give:
	 	"busId":3,
		"arrivalDate": "2022-04-18 10:00",
		"availableSeats":10 ,
		"bookedSeats":30,
		"busName":"Sharma Travels",
		"departureDate":"2022-04-18 14:00",
		"destinationCity":"Mumbai",
		"duration":4,
		"operator":"op1",
		"price":500,
		"sourceCity":"Nashik"
	 */
	
	@PostMapping("/addbus")
    public Bus addBus(@RequestBody Bus bus) 
	{		
        return busService.addNewBus(bus);
    }
	
	// get list of all bus
	@GetMapping("/buslist")
    public List <Bus> getAllBusDetails() 
	{	
        List<Bus> l= busService.getAllBusDetails();
        return l;
    }
	// admin will get all tickets
		@GetMapping("/tickets")
	    public List <Ticket> getAllTicketDetails() 
		{		
	        return (List<Ticket>) ticketRepository.findAll();
	    }
		
		// get list of all bus
		@DeleteMapping("/deleteBus/{busId}")
	    public void removeBus(@PathVariable("busId") long busId) throws Exception 
		{
	        busService.deleteBus(busId);
	    }
	
}
