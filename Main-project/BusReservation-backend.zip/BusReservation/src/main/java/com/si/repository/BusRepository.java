package com.si.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.si.entity.Bus;

@Repository
public interface BusRepository extends CrudRepository<Bus, Long>{
	
	@Query("SELECT b FROM Bus b WHERE sourceCity = ?1 "
			+ "and b.destinationCity = ?2"
			)
	List<Bus> findBySearchParameters(
			String sourceCity,
			String destinationCity
			);
	
	Bus findByBusName(String busName);
}
