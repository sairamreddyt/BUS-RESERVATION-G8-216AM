package com.si.service;
public class HelperBean {

	public HelperBean() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
	}

}