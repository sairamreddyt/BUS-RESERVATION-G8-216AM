package com.si.controller;
import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.si.entity.Bus;
import com.si.entity.Invoice;
import com.si.entity.User;
import com.si.service.BusService;
import com.si.service.UserService;

;

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/user")
public class UserController
{
	@Autowired
	private UserService userService;
	
	@Autowired
	private BusService busService;
	
	
	// add new user 
	/* Inputs:
	  	"userId":102,
    	"email":"sagar@yahoo.com",
    	"password":"sagar@12345",
    	"userName":"sagar"
    */
	@PostMapping("/login")        
   	public User userLogin(@RequestBody(required = true) User userDetail)
   	{                                                                                   
   		return userService.verifyUser(userDetail.getEmail(), userDetail.getPassword());                                                                                
   	}   
	
	@PostMapping("/adduser")
	public User addNewUser(@RequestBody  User user)
	{
		return userService.addUser(user);
	}
	// list of all registered users
	@GetMapping("/userlist")
	public List<User> getAllUsers()
	{
		return userService.getAllUserDetails();
	}
	/*User can book ticket by this method
	 parameters to pass:
		 busName:Sana Travels
		 seatNumber:20
		 userName:sagar
	 
	 output(invoice or ticket)
	 	"busName": "Sana Travels",
	    "operator": "Nikhil",
	    "departureDate": "2022-04-18T12:00:00.000+00:00",
	    "sourceCity": "Aurangabaad",
	    "destinationCity": "Mumbai",
	    "duration": 8,
	    "price": 1000,
	    "userName": "sagar",
	    "email": "sagar@yahoo.com"
	 
	 */
	
	@PostMapping("/bookBus")
	public Invoice bookTicket(@RequestParam(required = false) String busName,
    		@RequestParam(required = false) String seatNumber,
    		@RequestParam(required = false) String userName) throws Exception
	{
		return userService.bookTicket(busName, seatNumber, userName);
	}
	
	// user can search bus by providing source city and destination city
	/*
	 	Inputs:
	 		sourceCity:Pune
	 		destinationCity:Mumbai
	 		
	 	After entering input user will see output like this
	 		"busName": "Neeta Travels",
	        "operator": "samir",
	        "duration": 4,
	        "price": 600,
	        "availableSeats": "50",
	        "bookedSeats": "30,null,02,02,30",
	        "sourceCity": "Pune",
	        "destinationCity": "Mumbai",
	        "departureDate": "2022-04-15 05:30",
	        "arrivalDate": "2022-04-16 09:30"
	 */
	@GetMapping("/searchBus")
    public List <Bus> findBySearchParameters(@RequestParam(required = false) String sourceCity,
    		@RequestParam(required = true) String destinationCity) throws ParseException
	{
        return busService.findBySearchParameters(sourceCity, destinationCity);
    }
}
